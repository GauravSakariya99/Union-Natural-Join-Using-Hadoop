package union;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class union {
	public static class Mapper
		extends org.apache.hadoop.mapreduce.Mapper<Object, Text, Text, Text> {
	
	public void map(Object key, Text value, Context context
	) throws IOException, InterruptedException {
		context.write(value, value);
	}
   }
	public static class Reducer
	extends org.apache.hadoop.mapreduce.Reducer<Text, Text, Text, Text> {

	public void reduce(Text key, Iterable<Text> _values,
					   Context context
	) throws IOException, InterruptedException {
			context.write(key,new Text(""));
	}
	}

	public static void main(String[] args) throws Exception {
		 Configuration conf = new Configuration();
		 Job job = new Job(conf, "Union");
		 job.setJarByClass(union.class);
		 job.setReducerClass(Reducer.class);
		 job.setOutputKeyClass(Text.class);
		 job.setOutputValueClass(Text.class);
		  
		 MultipleInputs.addInputPath(job, new Path(args[0]),TextInputFormat.class, Mapper.class);
		 MultipleInputs.addInputPath(job, new Path(args[1]),TextInputFormat.class, Mapper.class);
		 Path outputPath = new Path(args[2]);
		  
		 FileOutputFormat.setOutputPath(job, outputPath);
		 outputPath.getFileSystem(conf).delete(outputPath);
		 System.exit(job.waitForCompletion(true) ? 0 : 1);
		 }
 
}